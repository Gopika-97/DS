package controller;

public class SensorController {

}
