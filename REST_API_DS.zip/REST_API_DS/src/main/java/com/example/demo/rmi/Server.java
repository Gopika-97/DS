package com.example.demo.rmi;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;

import org.springframework.beans.factory.annotation.Autowired;

import java.net.ConnectException;
import java.rmi.Remote;


import com.example.demo.repository.RemoteRepository;
import com.example.demo.repository.SensorRepository;
import com.example.demo.service.SensorService;
import java.rmi.RemoteException;
public class Server extends SensorService{

	public Server() {} 
	
	@Autowired
	public static void main(String args[]) throws ConnectException { 
	      try { 
	         // Instantiating the implementation class 
	         SensorService obj = new SensorService(); 
	    
	         // Exporting the object of implementation class (here we are exporting the remote object to the stub) 
	//         RemoteRepository stub = (RemoteRepository) UnicastRemoteObject.exportObject(obj, 0);  
	         
	         // Binding the remote object (stub) in the registry 
	         Registry registry = LocateRegistry.getRegistry(); 
	       // System.setProperty("java.rmi.server.hostname","192.168.43.163");
	//         registry.bind("Hello",(Remote) stub); 
	         
	         System.err.println("Server ready"); 
	      } catch (Exception e) { 
	         System.err.println("Server exception: " + e.toString()); 
	         e.printStackTrace(); 
	      } 
	   } 
	
}
