package com.example.demo.rmi;

import java.rmi.registry.LocateRegistry; 
import java.rmi.registry.Registry; 
import java.util.*;

import com.example.demo.model.Sensor;
import com.example.demo.repository.SensorRepository;  

public class Client {
	private Client() {}  
	   public static void main(String[] args)throws Exception {  
	      try { 
	         // Getting the registry 
	         Registry registry = LocateRegistry.getRegistry(null); 
	    
	         // Looking up the registry for the remote object 
	         SensorRepository stub = (SensorRepository) registry.lookup("Hello"); 
	    
	         // Calling the remote method using the obtained object 
	         Scanner sc =new Scanner (System.in);
	         int FNO = sc.nextInt();
	         List<Sensor> list = (List)stub.findByFloorNo(FNO); 
	         
	         for (Sensor s:list) { 
	           
	            System.out.println("Floor: " + s.getFloorNo()); 
	            System.out.println("Room: " + s.getRoomNo()); 
	            System.out.println("Smoke: " + s.getSmoke()); 
	            System.out.println("CO2: " + s.getCo2()); 
	            System.out.println("Status: " + s.getStatus()); 
	         }  
	      // System.out.println(list); 
	      } catch (Exception e) { 
	         System.err.println("Client exception: " + e.toString()); 
	         e.printStackTrace(); 
	      } 
	   } 
}
