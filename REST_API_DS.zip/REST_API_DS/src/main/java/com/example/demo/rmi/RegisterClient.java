package com.example.demo.rmi;

import java.net.Inet4Address;
import java.net.UnknownHostException;
import org.springframework.beans.factory.UnsatisfiedDependencyException;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.remoting.rmi.RmiProxyFactoryBean;

import com.example.demo.service.SensorService;

@Configuration
public class RegisterClient {

	@Bean
	public SensorService sensorSenService() {
		return new SensorService();
		
	}
	
	//@Bean
	  public RmiProxyFactoryBean exporter() throws UnknownHostException {
	      RmiProxyFactoryBean rpfb = new RmiProxyFactoryBean();
	      rpfb.setServiceInterface(SensorService.class);
	      String hostAddress = Inet4Address.getLocalHost()
	                                       .getHostAddress();
	      rpfb.setServiceUrl(String.format("rmi://%s:2099/OrderService", hostAddress));
	      return rpfb;
	  }

	  public static void main(String[] args) {
	      AnnotationConfigApplicationContext context =
	              new AnnotationConfigApplicationContext(SensorClient.class);
	      SensorBean bean = context.getBean(SensorBean.class);
	      bean.clientRun();
	     
	  }
}
