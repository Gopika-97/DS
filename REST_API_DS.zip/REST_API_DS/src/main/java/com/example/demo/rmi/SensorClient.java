package com.example.demo.rmi;

public class SensorClient {

}
