package com.example.demo.service;

import java.util.List;
import java.util.Optional;
import java.rmi.Remote;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Service;

import com.example.demo.model.Sensor;
import com.example.demo.repository.RemoteRepository;
import com.example.demo.repository.SensorRepository;

@Service
public class SensorService{
	
	@Autowired
	private SensorRepository sensorRepository = new SensorRepository() {
		
		@Override
		public <S extends Sensor> Optional<S> findOne(Example<S> example) {
			// TODO Auto-generated method stub
			return null;
		}
		
		@Override
		public <S extends Sensor> Page<S> findAll(Example<S> example, Pageable pageable) {
			// TODO Auto-generated method stub
			return null;
		}
		
		@Override
		public <S extends Sensor> boolean exists(Example<S> example) {
			// TODO Auto-generated method stub
			return false;
		}
		
		@Override
		public <S extends Sensor> long count(Example<S> example) {
			// TODO Auto-generated method stub
			return 0;
		}
		
		@Override
		public <S extends Sensor> S save(S entity) {
			
			return null;
		}
		
		@Override
		public Optional<Sensor> findById(String id) {
			// TODO Auto-generated method stub
			return null;
		}
		
		@Override
		public Iterable<Sensor> findAllById(Iterable<String> ids) {
			// TODO Auto-generated method stub
			return null;
		}
		
		@Override
		public boolean existsById(String id) {
			// TODO Auto-generated method stub
			return false;
		}
		
		@Override
		public void deleteById(String id) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void deleteAll(Iterable<? extends Sensor> entities) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void deleteAll() {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void delete(Sensor entity) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public long count() {
			// TODO Auto-generated method stub
			return 0;
		}
		
		@Override
		public Page<Sensor> findAll(Pageable pageable) {
			// TODO Auto-generated method stub
			return null;
		}
		
		@Override
		public <S extends Sensor> List<S> saveAll(Iterable<S> entities) {
			// TODO Auto-generated method stub
			return null;
		}
		
		@Override
		public <S extends Sensor> List<S> insert(Iterable<S> entities) {
			// TODO Auto-generated method stub
			return null;
		}
		
		@Override
		public <S extends Sensor> S insert(S entity) {
			// TODO Auto-generated method stub
			return null;
		}
		
		@Override
		public <S extends Sensor> List<S> findAll(Example<S> example, Sort sort) {
			// TODO Auto-generated method stub
			return null;
		}
		
		@Override
		public <S extends Sensor> List<S> findAll(Example<S> example) {
			// TODO Auto-generated method stub
			return null;
		}
		
		@Override
		public List<Sensor> findAll(Sort sort) {
			// TODO Auto-generated method stub
			return null;
		}
		
		@Override
		public List<Sensor> findAll() {
			// TODO Auto-generated method stub
			return null;
		}
		
		@Override
		public Sensor findByRoomNo(int floorNo, int roomNo) {
			// TODO Auto-generated method stub
			return null;
		}
		
		@Override
		public List<Sensor> findByFloorNo(int floorNo) {
			// TODO Auto-generated method stub
			return null;
		}
	};
	
	//create operations 
	public Sensor create (int floorNo,int roomNo,int smoke,int co2,int Status) {
		Sensor s =new Sensor(floorNo, roomNo, smoke, co2, Status);
		System.out.println(s);
		return sensorRepository.save(s);
	}
	
	
	//retrieve operations
	
	public List<Sensor> getAll(){
		return sensorRepository.findAll();	
	}
	
	public Sensor getByRoomNo(int floorNo,int roomNo) {
		return sensorRepository.findByRoomNo(floorNo,roomNo);
	}
	

	
	//update operations
	public Sensor update (int floorNo,int roomNo,int smoke,int co2,int status) {
		Sensor s=sensorRepository.findByRoomNo(floorNo,roomNo);
		System.out.println(s);
		s.setSmoke(smoke);
		s.setCo2(co2);
		s.setStatus(status);
		return sensorRepository.save(s);
	}
	
	//delete operations
	public void deleteAll () {
		sensorRepository.deleteAll();
	}
	public void delete(int floorNo,int roomNo) {
		Sensor s = sensorRepository.findByRoomNo(floorNo,roomNo);
		sensorRepository.delete(s);
	}

	public List<Sensor> getByFloorNo(int floorNo) {
		// TODO Auto-generated method stub
		return  sensorRepository.findByFloorNo(floorNo);
	}




	
	
}
 