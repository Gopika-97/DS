package com.example.demo.rmi;

import java.rmi.Remote;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.demo.model.Sensor;


public interface SensorFacade extends Remote {
	
	
	public List<Sensor> findByFloorNo(int floorNo);
	public Sensor findByRoomNo(int floorNo, int roomNo);
	
	
}
