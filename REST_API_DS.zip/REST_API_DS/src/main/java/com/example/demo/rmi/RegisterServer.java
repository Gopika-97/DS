/*

package com.example.demo.rmi;

import java.net.UnknownHostException;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.remoting.rmi.RmiServiceExporter;

import com.example.demo.service.SensorService;

@Configuration
public class RegisterServer {
	
	SensorService ss1=new SensorService();
	
	@Bean
	  public RmiServiceExporter exporter() throws UnknownHostException {
	      RmiServiceExporter rse = new RmiServiceExporter();
	      rse.setServiceName("ServiceService");
	      rse.setService(ss1.getAll());
	      rse.setServiceInterface(SensorService.class);
	      rse.setRegistryPort(1099);
	      return rse;
	  }
	
	  public static void main(String[] args) {
	      new AnnotationConfigApplicationContext(RegisterServer.class);
	  }
}

*/