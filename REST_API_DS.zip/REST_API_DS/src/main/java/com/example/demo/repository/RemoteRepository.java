package com.example.demo.repository;

import java.rmi.Remote;
import java.rmi.RemoteException; 
import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.model.Sensor;

@Repository
public interface RemoteRepository  extends Remote{

	
		
		public List<Sensor> findByFloorNo(int floorNo) throws Exception;
	
		

}
