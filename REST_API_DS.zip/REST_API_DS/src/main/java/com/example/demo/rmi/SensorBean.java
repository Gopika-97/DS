package com.example.demo.rmi;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.demo.service.SensorService;

public class SensorBean {

	@Autowired
	  private SensorService sensorService;
	
	public void clientRun() {
		System.out.print("Client Running");
	}
	
}
