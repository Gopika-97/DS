package com.example.demo;
  
import java.io.IOException;
import java.net.URL;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.model.Sensor;


@SpringBootApplication
public class RestApiDsDesktopApplication {

	public RestTemplate getRestTemplate() {
		System.out.println("startded restTemp...");
		return new RestTemplate();
	}
	
	public static void main(String[] args) {
		SpringApplication.run(RestApiDsDesktopApplication.class, args);
		System.out.println("startded...");
		
		/*
		ObjectMapper mapper = new ObjectMapper();
		try {
			Sensor sensor = mapper.readValue(new URL("http://localhost:8080/getFloor?floorNo=3"), Sensor.class);
			System.out.println("Json values CO2 value :"+sensor.getCo2());
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		*/
		
		Sensor sensor;
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<List<Sensor>> rateResponse =restTemplate.exchange("http://localhost:8080/getFloor?floorNo=3", HttpMethod.GET, null, new ParameterizedTypeReference<List<Sensor>>() {});
		List<Sensor> rates = rateResponse.getBody();
		System.out.println(rates);

		System.out.println("finished...");

	
	}

}
