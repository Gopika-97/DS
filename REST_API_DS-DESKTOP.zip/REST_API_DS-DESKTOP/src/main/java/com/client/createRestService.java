package com.client;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;



import com.model.Sensor;

@Component
public class createRestService{

	private static void createRestService()  {
		RestTemplate restTemplate = new RestTemplate();
		Sensor sensor1 = restTemplate.getForObject("http://localhost:8080/getFloor?floorNo=3", Sensor.class);
		System.out.print("Here is the smoke level"+sensor1.getSmoke());
		int smoke =sensor1.getSmoke();
		int co2 =sensor1.getCo2();
		System.out.println("Checkig errors");
	}


	
	
}
