package com.controller;

import java.util.List;
import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.client.RestTemplate;

public class DetailsController {
	
	@Autowired
	private RestTemplate restTemplate;
	
	@GetMapping("/sensors")
	public List<Object> getSensor (){
		String url = "http://localhost:8080/getFloor?floorNo=3";
		Object[] objects = restTemplate.getForObject(url, Object[].class) ;
		System.out.println(objects);
		return Arrays.asList(objects);
	}

}
