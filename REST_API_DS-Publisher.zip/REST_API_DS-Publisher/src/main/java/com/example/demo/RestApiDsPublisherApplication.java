package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestApiDsPublisherApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestApiDsPublisherApplication.class, args);
	}

}
