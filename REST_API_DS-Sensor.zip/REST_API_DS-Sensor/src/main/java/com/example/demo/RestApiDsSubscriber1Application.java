package com.example.demo;

import java.util.Timer;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.demo.GetRequest;

@SpringBootApplication
public class RestApiDsSubscriber1Application {

	public static void main(String[] args) {
		SpringApplication.run(RestApiDsSubscriber1Application.class, args);
		 System.out.println("main method");
			Timer timer1 = new Timer();
			timer1.schedule(new GetRequest(), 0, 30000);
	}

}
